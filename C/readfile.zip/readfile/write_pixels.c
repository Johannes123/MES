#include <write_pixels.h>

int write_pixels(char *file_out, struct px *pixel, int *width, int *height, int *color_depth)
{
    int x = *width;
    int y = *height;
    int clr_dpth = *color_depth;
    printf("file_out: %s\n", file_out);
    FILE *filepointer = fopen(file_out, "w+");
	    printf("lol\n"); 
		//write P3
		fprintf(filepointer, "P3\n");
		//write comment #
		fprintf(filepointer, "# blablabla\n");
		//write pixel x and y, read color depth
		fprintf(filepointer, "%d %d\n%d\n", &x, &y, &clr_dpth);
       
        int i_x, i_y;
		for(i_x = 0; i_x < x; i_x++)
		{
			for(i_y = 0; i_y < y; i_y++)
			{
				fprintf(filepointer, "%u %u %u", pixel->r, pixel->g, pixel->b);
				pixel++;
			}
		}

    fclose(filepointer);
    return 0;
}