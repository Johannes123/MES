#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <stdbool.h>
#include <unistd.h>
#include <read_pixels.h>
#include <write_pixels.h>

void print_help(void);
int read_pixels(char *file_in, struct px **pixel, int *width, int *height, int *color_depth);
int write_pixels(char *file_out, struct px *pixel, int *width,  int *height, int *color_depth);

int main (int argc, char *argv[])
{
	struct px *mypixel;
	int x, y, clr_dpth;

	// no arguments given
	if(argc == 1) 
	{
		fprintf (stderr, "This program needs arguments ...\n\n");
		print_help();
	}
	
	// get the arguments
	int opt, n = INT_MIN;
	int larg, varg, warg, rarg, garg, barg = INT_MIN;
	char iarg[50], oarg[50];
	while ( (opt = getopt (argc, argv, "i:o:l:v:w:r:g:b:h")) != -1) 
	{
		switch (opt) 
		{
		case 'i':
			n = sscanf (optarg, "%s", iarg);
			assert (n == 1);
			break;
		case 'o':
			n = sscanf (optarg, "%s", oarg);
			assert (n == 1);
			break;
		case 'l':
			n = sscanf (optarg, "%d", &larg);
			assert (n == 1);
			break;
		case 'v':
			n = sscanf (optarg, "%d", &varg);
			assert (n == 1);
			break;
		case 'w':
			n = sscanf (optarg, "%d", &warg);
			assert (n == 1);
			break;
		case 'r':
			n = sscanf (optarg, "%d", &rarg);
			assert (n == 1);
			break;
		case 'g':
			n = sscanf (optarg, "%d", &garg);
			assert (n == 1);
			break;
		case 'b':
			n = sscanf (optarg, "%d", &barg);
			assert (n == 1);
			break;
		case 'h':
			print_help();
			break;
		case ':':
			fprintf (stderr, "Option requires an argument.\n");
			print_help ();
			break;
		case '?':
			fprintf (stderr, "Unknown option character %c.\n", optopt);
			print_help ();
			break;
		default: break;	
		}
	}
  
	for (; optind < argc; optind++)
    printf ("argument: %s\n", argv[optind]);

  // now we print the parameters we have got
	if (strcmp(iarg,"")!=0)
		printf ("%s was invoked with -i %s\n", argv[0], iarg);
	if (strcmp(oarg,"")!=0)
		printf ("%s was invoked with -o %s\n", argv[0], oarg);
	if (larg != INT_MIN)
		printf ("%s was invoked with -l %d\n", argv[0], larg);
	if (varg != INT_MIN)
		printf ("%s was invoked with -v %d\n", argv[0], varg);
	if (warg != INT_MIN)
		printf ("%s was invoked with -w %d\n", argv[0], warg);
	if (rarg != INT_MIN)
		printf ("%s was invoked with -r %d\n", argv[0], rarg);
	if (garg != INT_MIN)
		printf ("%s was invoked with -g %d\n", argv[0], garg);
	if (barg != INT_MIN)
		printf ("%s was invoked with -b %d\n", argv[0], barg);

	read_pixels(iarg, &mypixel, &x, &y, &clr_dpth);
	write_pixels(oarg, mypixel, &x, &y, &clr_dpth);
	
	return 0;
}

void print_help (void)
{
	printf ("Syntax:\n");
	printf ("prog [-i filename in]\n [-o filename out]\n [-l horizontal lines]\n [-v vertical lines]\n [-w line width]\n [-r red]\n [-g green]\n [-b blue]\n [-h help]\n\n");
	exit (EXIT_FAILURE);
}