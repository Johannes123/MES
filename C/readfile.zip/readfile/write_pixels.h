#ifndef _write_pixels_
#define _write_pixels_
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <stdbool.h>
#include <unistd.h>
#include <read_pixels.h>

int write_pixels(char *file_out, struct px *pixel, int *width, int *height, int *color_depth);

#endif